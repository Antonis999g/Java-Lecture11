import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collections;
import java.util.ArrayList;

import javax.swing.*;

public class GUI extends JFrame{
	private JPanel panel;
	private JTextField inputField;
	private JButton addButton;
	private JButton sortButton;
	private JList<String> list;
	private DefaultListModel<String> model;
	
	public GUI(){
		panel = new JPanel();
		
		inputField = new JTextField(10);
		addButton = new JButton("Add");
		sortButton = new JButton("Sort");
		
		model = new DefaultListModel<>();
		list = new JList<>();
		list.setModel(model);
		
		JScrollPane scrollPane = new JScrollPane(list);
		
		panel.add(inputField);
		panel.add(addButton);
		panel.add(scrollPane);
		panel.add(sortButton);
		
		this.setContentPane(panel);
		
		addButton.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				model.addElement( inputField.getText());
				inputField.setText("");
				
			}  });
		sortButton.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				ArrayList<String> list = Collections.list(model.elements());
				Collections.sort(list);
				model.clear();
			}
		});
		
		this.setVisible(true);
		this.setSize(500,500);
		
		
	}

}
